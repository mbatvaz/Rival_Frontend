# Rival DS v1 snapshot
- Source: https://claude.ai/artifact/VNKcocXpXh3LgPG1gE9To8
- Version: 1791735698-27f8 (lastChange 2026-10-11T16:21:26Z)
- Taken: 2026-10-23, before v2 work. All text files (tokens, bundle, README, design-system.json, 37 cards + READMEs, asset READMEs).
- Not copied (unchanged in v2, kept on the artifact): fonts/*.woff2, image blobs, assets/*.md archive docs, generated api/.
- Rollback: republish these files to the same artifact (files left out are kept).
