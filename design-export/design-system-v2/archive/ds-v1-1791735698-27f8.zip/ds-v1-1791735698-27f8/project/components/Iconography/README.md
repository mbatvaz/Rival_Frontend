# Iconography

۷۱ آیکون خطی Lucide (ISC) با خط ۱.۷۵ و `currentColor`: `<i class="ri ri-NAME">`، اندازه‌ها `ri-sm` ۱۶، پیش‌فرض ۲۰، `ri-lg` ۲۴، `ri-xl` ۳۶.

آیکونی که تنها می‌نشیند روی کاشی گرادیانی `.rv-tile` است؛ کاشی کروم برای خنثی و نُه تن (`is-ink`، `is-accent`، `is-success`، `is-warning`، `is-info`، `is-plum`، `is-rose`، `is-danger`، `is-neutral`) فقط وقتی معنا دارند.
