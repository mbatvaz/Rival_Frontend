# Navigation

- **نوار بالا** (`.rv-topbar`) زمینه صفحه را می‌دهد، نه هویت کاربر — نام و عکس خود کاربر اینجا نمی‌آید (در تب «حساب» است):
  - خانه مشتری: لوگو (`.rv-logo-ink`) و زنگ اعلان؛
  - خانه آرایشگر و مدیر: عنوان صفحه («امروز» با `heading-xl`) و تاریخ همان روز، و زنگ با شمارنده؛
  - صفحه جزئیات: بازگشت `ri-arrow-right`، عنوان، «بیشتر»؛
  - مدیر: لوگو و Scope «من / آرایشگر / همه سالن».
- **نوار پایین شناور** (`.rv-dock`): یک کپسول شیشه‌ای `.rv-nav.rv-glass-strong` که تب‌ها در آن فقط آیکون‌اند؛ تب فعال (`aria-current="page"`) به یک قرص جوهری تخت باز می‌شود و برچسبش (`.rv-nav__l`) با حرکت فنری ظاهر می‌شود.
- **دکمه رزرو مشتری** (`.rv-dock--book` + `.rv-dock__book`): کپسول تب‌ها سمت راست و دکمه «رزرو» جدا سمت چپ آن. دکمه همان شکل تب فعال را دارد — قرص جوهری با آیکون `calendar-plus` و برچسب «رزرو» — اما برچسبش همیشه دیده می‌شود تا کاربر بداند این دکمه برای رزرو است. دایره فقط‌آیکون یا رنگ تاکید نیست. در صفحه رزرو هیچ تبی در کپسول فعال نیست و دور دکمه حلقه جوهری می‌افتد (`aria-current="page"`). در این حالت تب‌ها کمی فشرده‌ترند تا هر دو در عرض ۳۶۰px جا شوند. آرایشگر و مدیر دکمه رزرو ندارند.

```html
<div class="rv-dock rv-dock--book">
  <nav class="rv-nav rv-glass-strong" aria-label="مشتری">
    <a href="/" aria-current="page" aria-label="خانه"><span class="rv-nav__ic"><i class="ri ri-home"></i></span><span class="rv-nav__l">خانه</span></a>
    <a href="/appointments" aria-label="نوبت‌ها"><span class="rv-nav__ic"><i class="ri ri-calendar"></i></span><span class="rv-nav__l">نوبت‌ها</span></a>
    <a href="/wallet" aria-label="کیف پول"><span class="rv-nav__ic"><i class="ri ri-wallet"></i></span><span class="rv-nav__l">کیف پول</span></a>
    <a href="/account" aria-label="حساب"><span class="rv-nav__ic"><i class="ri ri-user"></i></span><span class="rv-nav__l">حساب</span></a>
  </nav>
  <a href="/book" class="rv-dock__book" aria-label="رزرو نوبت"><i class="ri ri-calendar-plus"></i><span>رزرو</span></a>
</div>
```

- هر تب `aria-label` دارد چون برچسب فقط در تب فعال دیده می‌شود. حداکثر ۵ تب (یا ۴ تب + دکمه رزرو)؛ نشان عددی `.rv-nav__badge` (داخل `.rv-nav__ic`) فقط برای موارد باز.
- `.rv-dock--static` برای نمایش بیرون از قاب صفحه.
