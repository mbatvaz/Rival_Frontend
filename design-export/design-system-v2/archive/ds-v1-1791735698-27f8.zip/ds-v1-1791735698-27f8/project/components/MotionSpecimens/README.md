# MotionSpecimens

نمونه زنده هر حرکت: پاپ انتخاب، لغزیدن کپسول روز، برگه از پایین، toast، کشیده شدن تیک، حلقه نگه‌داشت، تپش «اکنون» و تکان آیکون‌ها در لحظه معنا. مدت‌ها `duration-fast/base/slow/deliberate` و منحنی‌ها `ease-standard`، `ease-exit`، `ease-spring`. زیر `prefers-reduced-motion` همه حذف می‌شوند.
