# CalendarDayPicker

انتخاب روز برای مشتری: فقط روزهای قابل رزرو کاشی سفید برجسته‌اند؛ گذشته، پر و تعطیل تخت و کم‌رنگ می‌مانند.

- `.rv-cal.rv-cal--avail.rv-glass` > `.rv-cal__head` + `.rv-cal__grid` (۷ ستون با `.rv-cal__dow`).
- روز: `.rv-day` با `.is-open`، `.is-few` (نقطه `warning`)، `.is-full`، `.is-past`، `.is-holiday` (قرمز)، `.is-today` (نقطه سبز)، انتخاب `aria-selected="true"` جوهری با پاپ.
- کنار آن زمان‌ها با `.rv-slot-group` (صبح، ظهر، عصر) و اگر زمان دلخواه پر بود، پیشنهاد «اعلان آزاد شدن» (بدون اولویت و بدون نگه‌داشت).
