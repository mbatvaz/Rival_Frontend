# WeekStrip

نسخه بازطراحی‌شده: پنل شیشه‌ای هفت روز برابر با کپسول جوهری که به روز انتخاب‌شده **می‌لغزد**.

```html
<div class="rv-week rv-glass">
  <div class="rv-week__head">…ماه، امروز، قبل/بعد…</div>
  <div class="rv-week__grid" role="tablist" style="--i:5">
    <span class="rv-week__ind" aria-hidden="true"></span>
    <button class="rv-wd is-today" role="tab" aria-selected="true"><small>پ</small><b>۱۶</b><span class="rv-load"><i class="on"></i><i class="on"></i><i></i></span></button>
    …
  </div>
  <div class="rv-week__foot">پنجشنبه ۱۶ مهر …</div>
</div>
```

- `--i` شماره ستون انتخاب‌شده (۰ = شنبه) است؛ کپسول با `ease-spring` جابه‌جا می‌شود. در Alpine: `:style="'--i:'+day"`.
- `.rv-load` سه پله بار روز (کم، متوسط، پر). `.is-today` نقطه سبز، `.is-past` عدد کم‌رنگ، `.is-off` تعطیل خط‌خورده و غیرقابل انتخاب.
- برای برنامه آرایشگر، فهرست نوبت مدیر و انتخاب سریع روز در رزرو.
